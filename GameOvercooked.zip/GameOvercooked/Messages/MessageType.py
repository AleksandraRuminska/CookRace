from enum import IntEnum


class MessageType(IntEnum):
    SPAWN = 1
    MOVE = 2
    PICKUP = 3
